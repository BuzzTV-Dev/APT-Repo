#!/bin/env bash

cd "${0%/*}" || exit 1
APP_DIR="/opt/buzztv_dsw"

"${APP_DIR?:}"/buzztv_dsw -b "${APP_DIR?:}"/ --async-vblank --no-cursor

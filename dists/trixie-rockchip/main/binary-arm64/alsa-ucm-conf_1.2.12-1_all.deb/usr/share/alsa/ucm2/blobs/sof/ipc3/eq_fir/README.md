# How to build

These blobs were exported with example_fir_eq.m tool from
[SOF](https://github.com/thesofproject/sof)

Usage:
cd tools/tune/eq; octave --no-window-system example_fir_eq.m

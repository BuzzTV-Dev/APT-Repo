# How to build

These blobs were exported with example_drc.m tool from
[SOF](https://github.com/thesofproject/sof)

Usage:
cd tools/tune/drc; octave --no-window-system example_drc.m

/* gstvkconfig.h
 *
 * This is a generated file.  Please modify `gstvkconfig.h.meson'
 */

#ifndef __GST_VULKAN_CONFIG_H__
#define __GST_VULKAN_CONFIG_H__

#include <gst/gst.h>

G_BEGIN_DECLS

#define GST_VULKAN_HAVE_WINDOW_XCB 1
#define GST_VULKAN_HAVE_WINDOW_WAYLAND 1
#define GST_VULKAN_HAVE_WINDOW_COCOA 0
#define GST_VULKAN_HAVE_WINDOW_IOS 0
#define GST_VULKAN_HAVE_WINDOW_WIN32 0
#define GST_VULKAN_HAVE_WINDOW_ANDROID 0
#define GST_VULKAN_HAVE_VIDEO_EXTENSIONS 1

G_END_DECLS

#endif  /* __GST_VULKAN_CONFIG_H__ */

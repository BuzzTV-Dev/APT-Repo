var searchData=
[
  ['values_0',['values',['../group__opt__read.html',1,'Reading option values'],['../group__opt__write.html',1,'Setting and modifying option values']]],
  ['vdpau_20decoder_20and_20renderer_1',['VDPAU Decoder and Renderer',['../group__lavc__codec__hwaccel__vdpau.html',1,'']]],
  ['version_20and_20build_20diagnostics_2',['Version and Build diagnostics',['../group__lavu__ver.html',1,'']]],
  ['version_20macros_3',['Library Version Macros',['../group__version__utils.html',1,'']]],
  ['video_20mapping_4',['Spherical video mapping',['../group__lavu__video__spherical.html',1,'']]],
  ['video_20related_5',['Video related',['../group__lavu__video.html',1,'']]],
  ['videotoolbox_20decoder_6',['VideoToolbox Decoder',['../group__lavc__codec__hwaccel__videotoolbox.html',1,'']]]
];

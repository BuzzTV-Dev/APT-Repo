var searchData=
[
  ['data_20structures_0',['Data Structures',['../group__lavu__data.html',1,'']]],
  ['decoder_1',['VideoToolbox Decoder',['../group__lavc__codec__hwaccel__videotoolbox.html',1,'']]],
  ['decoder_20and_20renderer_2',['VDPAU Decoder and Renderer',['../group__lavc__codec__hwaccel__vdpau.html',1,'']]],
  ['decoding_3',['Decoding',['../group__lavc__decoding.html',1,'']]],
  ['decoding_20api_20overview_4',['send/receive encoding and decoding API overview',['../group__lavc__encdec.html',1,'']]],
  ['definition_5',['Parameter Definition',['../group__lavu__iamf__params.html',1,'']]],
  ['demuxers_6',['demuxers',['../group__lavf__codec.html',1,'Demuxers'],['../group__lavf__codec__native.html',1,'Native Demuxers']]],
  ['demuxing_7',['Demuxing',['../group__lavf__decoding.html',1,'']]],
  ['deprecation_20guards_8',['Deprecation Guards',['../group__lavu__depr__guards.html',1,'']]],
  ['des_9',['DES',['../group__lavu__des.html',1,'']]],
  ['device_20context_20creation_20flags_10',['Device context creation flags',['../group__hwcontext__cuda.html',1,'']]],
  ['diagnostics_11',['Version and Build diagnostics',['../group__lavu__ver.html',1,'']]],
  ['direct3d11_12',['Direct3D11',['../group__lavc__codec__hwaccel__d3d11va.html',1,'']]],
  ['display_20transformation_20matrix_20functions_13',['Display transformation matrix functions',['../group__lavu__video__display.html',1,'']]],
  ['downmix_20metadata_14',['Audio downmix metadata',['../group__downmix__info.html',1,'']]],
  ['dxva2_15',['DXVA2',['../group__lavc__codec__hwaccel__dxva2.html',1,'']]],
  ['dynamic_20array_16',['Dynamic Array',['../group__lavu__mem__dynarray.html',1,'']]]
];

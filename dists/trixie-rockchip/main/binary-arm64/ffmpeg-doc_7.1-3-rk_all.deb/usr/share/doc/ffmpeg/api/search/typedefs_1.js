var searchData=
[
  ['pp_5fcontext_0',['pp_context',['../group__lpp.html#ga0bbbccc0c988dfe2359f66e74933c51d',1,'postprocess.h']]],
  ['pp_5fmode_1',['pp_mode',['../group__lpp.html#gab32903357ef0a647034c2f8f1a3aad0c',1,'postprocess.h']]]
];

var searchData=
[
  ['rockchip_5frfbc_5fblock_5fsize_5f64x4_0',['ROCKCHIP_RFBC_BLOCK_SIZE_64x4',['../hwcontext__rkmpp_8h.html#a97a31381a17c89d3c7347feca7150c3a',1,'hwcontext_rkmpp.h']]],
  ['rounded_5fdiv_1',['ROUNDED_DIV',['../common_8h.html#a7a2a86492a286d6d20678da1dbb00525',1,'common.h']]],
  ['rshift_2',['RSHIFT',['../common_8h.html#aa79ca71ef110a498d8275cbf7aa75a93',1,'common.h']]]
];

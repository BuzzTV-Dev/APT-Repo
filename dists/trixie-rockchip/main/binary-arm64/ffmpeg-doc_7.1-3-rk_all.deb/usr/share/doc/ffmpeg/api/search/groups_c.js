var searchData=
[
  ['macros_0',['macros',['../group__version__utils.html',1,'Library Version Macros'],['../group__preproc__misc.html',1,'Preprocessor String Macros']]],
  ['management_1',['management',['../group__lavu__mem__funcs.html',1,'Heap Management'],['../group__lavu__mem.html',1,'Memory Management']]],
  ['manipulation_2',['manipulation',['../group__lavu__sampmanip.html',1,'Samples manipulation'],['../group__lavu__string.html',1,'String Manipulation']]],
  ['mapping_3',['Spherical video mapping',['../group__lavu__video__spherical.html',1,'']]],
  ['masks_4',['Audio channel masks',['../group__channel__masks.html',1,'']]],
  ['mathematics_5',['Mathematics',['../group__lavu__math.html',1,'']]],
  ['matrix_20functions_6',['Display transformation matrix functions',['../group__lavu__video__display.html',1,'']]],
  ['md5_7',['MD5',['../group__lavu__md5.html',1,'']]],
  ['media_20type_8',['Media Type',['../group__lavu__media.html',1,'']]],
  ['memory_20management_9',['Memory Management',['../group__lavu__mem.html',1,'']]],
  ['metadata_10',['Audio downmix metadata',['../group__downmix__info.html',1,'']]],
  ['metadata_20api_11',['Public Metadata API',['../group__metadata__api.html',1,'']]],
  ['miscellaneous_20functions_12',['Miscellaneous Functions',['../group__lavu__mem__misc.html',1,'']]],
  ['mix_20presentation_13',['Mix Presentation',['../group__lavu__iamf__mix.html',1,'']]],
  ['model_20and_20formats_14',['Immersive Audio Model and Formats',['../group__lavu__iamf.html',1,'']]],
  ['modifying_20option_20values_15',['Setting and modifying option values',['../group__opt__write.html',1,'']]],
  ['murmur3_16',['Murmur3',['../group__lavu__murmur3.html',1,'']]],
  ['muxing_17',['Muxing',['../group__lavf__encoding.html',1,'']]]
];

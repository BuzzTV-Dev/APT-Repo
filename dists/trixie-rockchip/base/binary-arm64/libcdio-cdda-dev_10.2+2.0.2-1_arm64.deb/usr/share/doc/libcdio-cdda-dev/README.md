[![Build Status Circle](https://circleci.com/gh/rocky/libcdio-paranoia.svg?&style=shield)](https://circleci.com/gh/rocky/libcdio-paranoia) [![Packaging status](https://repology.org/badge/tiny-repos/libcdio-paranoia.svg)](https://repology.org/project/libcdio-paranoia/versions)

[![Packaging status](https://repology.org/badge/vertical-allrepos/libcdio-paranoia.svg)](https://repology.org/project/libcdio-paranoia/versions)



This is a port of xiph.org's [cdda paranoia](https://www.xiph.org/paranoia/) to use libcdio for CDROM access. By doing this, cdparanoia runs on platforms other than GNU/Linux.

See the [CDDA FAQ](https://www.xiph.org/paranoia/faq.html) for more information about cdparanoia.

# @babel/plugin-transform-reserved-words

> Ensure that no reserved words are used.

See our website [@babel/plugin-transform-reserved-words](https://babeljs.io/docs/en/babel-plugin-transform-reserved-words) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-reserved-words
```

or using yarn:

```sh
yarn add @babel/plugin-transform-reserved-words --dev
```

#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rabbitmq::rabbitmq" for configuration "None"
set_property(TARGET rabbitmq::rabbitmq APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(rabbitmq::rabbitmq PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/librabbitmq.so.0.15.0"
  IMPORTED_SONAME_NONE "librabbitmq.so.4"
  )

list(APPEND _cmake_import_check_targets rabbitmq::rabbitmq )
list(APPEND _cmake_import_check_files_for_rabbitmq::rabbitmq "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/librabbitmq.so.0.15.0" )

# Import target "rabbitmq::rabbitmq-static" for configuration "None"
set_property(TARGET rabbitmq::rabbitmq-static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(rabbitmq::rabbitmq-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/librabbitmq.a"
  )

list(APPEND _cmake_import_check_targets rabbitmq::rabbitmq-static )
list(APPEND _cmake_import_check_files_for_rabbitmq::rabbitmq-static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/librabbitmq.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

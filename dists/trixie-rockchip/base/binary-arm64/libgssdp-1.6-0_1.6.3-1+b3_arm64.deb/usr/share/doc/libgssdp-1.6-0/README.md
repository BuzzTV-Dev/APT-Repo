GSSDP
=====

A GObject-based API for handling resource discovery and announcement over SSDP.

var ngram__search__fwdflat_8c =
[
    [ "ngram_fwdflat_deinit", "ngram__search__fwdflat_8c.html#a8faf467f90162a7273b23304fc6e8586", null ],
    [ "ngram_fwdflat_finish", "ngram__search__fwdflat_8c.html#ac855cf540ac4acdfa320629720ded6fe", null ],
    [ "ngram_fwdflat_init", "ngram__search__fwdflat_8c.html#ad4b8ebd904c77f8a28f59cd5ca2c8307", null ],
    [ "ngram_fwdflat_reinit", "ngram__search__fwdflat_8c.html#aa4879c06ddbc455a6f355084a9c574b4", null ],
    [ "ngram_fwdflat_search", "ngram__search__fwdflat_8c.html#ae77ef21ae92dbcc4b14f40469fbd4307", null ],
    [ "ngram_fwdflat_start", "ngram__search__fwdflat_8c.html#a763c2c7aaa5d7f9c5107af73552a2149", null ]
];
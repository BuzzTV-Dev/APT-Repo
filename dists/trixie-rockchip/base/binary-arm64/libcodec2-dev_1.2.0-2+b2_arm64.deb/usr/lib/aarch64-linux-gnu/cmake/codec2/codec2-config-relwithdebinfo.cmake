#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "codec2" for configuration "RelWithDebInfo"
set_property(TARGET codec2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(codec2 PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libcodec2.so.1.2"
  IMPORTED_SONAME_RELWITHDEBINFO "libcodec2.so.1.2"
  )

list(APPEND _cmake_import_check_targets codec2 )
list(APPEND _cmake_import_check_files_for_codec2 "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libcodec2.so.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

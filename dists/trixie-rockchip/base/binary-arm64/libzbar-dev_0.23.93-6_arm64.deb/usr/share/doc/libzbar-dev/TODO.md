general
=======

  * finish error handling
  * handle video destroyed w/images outstanding
  * dbg_scan background image stretched (still...)
  * profile and weed out obvious oversights
  * example using SANE to scan symbol(s)

windows port
============

  * libzbar-0.dll should be zbar-0.dll

wrappers
========

  * build API docs for zbargtk, zbarpygtk
  * is zbargtk/QZBar BGR4 alpha swapped?
  * widget config APIs
  * drag-and-drop for widgets (configurable...)
  * Perl build support integration?
  * GTK and Qt perl bindings
  * C++ global wrappers

symbologies
===========

  * PDF417
    * extract/resolve symbol matrix parameters (NB multiple symbols)
    * error detection/correction
    * high-level decode
  * Code 39, i25 optional features (check digit and ASCII escapes)
  * handle Code 128 function characters (FNC1-4)
  * Code 128 trailing quiet zone checks

decoder
=======

  * start/stop/abort and location detail APIs (PDF417, OMR)
  * more configuration options
    * disable for at least UPC-E (maybe UPC-A?)
    * Code-39/i25 check digit (after implementation)
    * Code-39 full ASCII (after implementation)
    * standard symbology identifiers (which standard?)
    * set consistency requirements
    * set scanner filter params
  * fix max length check during decode
  * revisit noise and resolution independence

image scanner
=============
  * extract and track symbol polygons
    * dynamic scan density (PDF417, OMR)
  * add multi-sample array interface to linear scanner

image formats
=============

  * fix image data inheritance
  * de-interlacing
  * add color support to conversions (also jpeg)
  * add support for scanline pad throughout
  * factor conversion redundancy

window
======

  * add XShm support
  * X protocol error handling
  * Direct2D
  * API to query used interface (video, window?) (/format?)
  * simple image manipulations scale(xv?)/mirror
    * maintain aspect ratio
  * more overlay details
    * decoded result(?)
    * stats

zbarcam/zbarimg
===============

  * zbarimg multi-frame duplicate suppression
  * stats/fps at zbarcam exit
  * decode hook (program/script)? (also zbarimg?)

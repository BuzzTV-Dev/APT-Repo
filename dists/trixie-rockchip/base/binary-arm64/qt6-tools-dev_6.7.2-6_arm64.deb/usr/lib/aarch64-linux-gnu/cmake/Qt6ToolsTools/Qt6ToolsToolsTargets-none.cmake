#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::qhelpgenerator" for configuration "None"
set_property(TARGET Qt6::qhelpgenerator APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::qhelpgenerator PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/libexec/qhelpgenerator"
  )

list(APPEND _cmake_import_check_targets Qt6::qhelpgenerator )
list(APPEND _cmake_import_check_files_for_Qt6::qhelpgenerator "${_IMPORT_PREFIX}/lib/qt6/libexec/qhelpgenerator" )

# Import target "Qt6::qtattributionsscanner" for configuration "None"
set_property(TARGET Qt6::qtattributionsscanner APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::qtattributionsscanner PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/libexec/qtattributionsscanner"
  )

list(APPEND _cmake_import_check_targets Qt6::qtattributionsscanner )
list(APPEND _cmake_import_check_files_for_Qt6::qtattributionsscanner "${_IMPORT_PREFIX}/lib/qt6/libexec/qtattributionsscanner" )

# Import target "Qt6::qdoc" for configuration "None"
set_property(TARGET Qt6::qdoc APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::qdoc PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/bin/qdoc"
  )

list(APPEND _cmake_import_check_targets Qt6::qdoc )
list(APPEND _cmake_import_check_files_for_Qt6::qdoc "${_IMPORT_PREFIX}/lib/qt6/bin/qdoc" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

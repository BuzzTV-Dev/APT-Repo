/* Simple Plugin API */
/* SPDX-FileCopyrightText: Copyright © 2018 Wim Taymans */
/* SPDX-License-Identifier: MIT */

#ifndef SPA_VIDEO_TYPES_H
#define SPA_VIDEO_TYPES_H

#include <spa/param/video/raw-types.h>

#endif /* SPA_VIDEO_TYPES_H */

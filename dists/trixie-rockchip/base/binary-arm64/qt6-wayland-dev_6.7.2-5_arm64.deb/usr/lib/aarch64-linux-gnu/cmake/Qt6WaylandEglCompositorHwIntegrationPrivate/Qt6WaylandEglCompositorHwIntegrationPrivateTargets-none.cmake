#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::WaylandEglCompositorHwIntegrationPrivate" for configuration "None"
set_property(TARGET Qt6::WaylandEglCompositorHwIntegrationPrivate APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::WaylandEglCompositorHwIntegrationPrivate PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQt6WaylandEglCompositorHwIntegration.so.6.7.2"
  IMPORTED_SONAME_NONE "libQt6WaylandEglCompositorHwIntegration.so.6"
  )

list(APPEND _cmake_import_check_targets Qt6::WaylandEglCompositorHwIntegrationPrivate )
list(APPEND _cmake_import_check_files_for_Qt6::WaylandEglCompositorHwIntegrationPrivate "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQt6WaylandEglCompositorHwIntegration.so.6.7.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

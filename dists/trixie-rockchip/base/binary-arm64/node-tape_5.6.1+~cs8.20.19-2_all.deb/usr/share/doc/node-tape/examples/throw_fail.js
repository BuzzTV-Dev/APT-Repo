'use strict';

var test = require('tape');

test('throw', function (t) {
	t.plan(2);

	setTimeout(function () {
		throw new Error('doom');
	}, 100);
});
